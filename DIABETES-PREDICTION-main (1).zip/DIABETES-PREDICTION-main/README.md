# Diabetes-Prediction-Model-using-Machine-Learning
A machine learning-based project developed for the ML AI course, providing accurate predictions of diabetes risk using medical data. Showcase of proficiency in ML and AI for healthcare applications.
